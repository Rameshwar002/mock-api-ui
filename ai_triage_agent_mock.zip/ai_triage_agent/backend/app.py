from flask import Flask, jsonify, request, send_from_directory
from pathlib import Path
from agents.orchestrator import TriageOrchestrator
from services.jira_service import JiraService
from services.azure_logs_service import AzureLogsService
from services.aia_service import AIAService
from services.history_service import HistoryService
from services.memory_service import MemoryService

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
app = Flask(__name__, static_folder=str(BASE.parent / "frontend"))

agent = TriageOrchestrator(
    JiraService(DATA/"tickets.json"),
    AzureLogsService(DATA/"azure_logs.json"),
    AIAService(DATA/"aia_documents.json"),
    HistoryService(DATA/"historical_tickets.json"),
    MemoryService(DATA/"rules.json")
)

@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.get("/api/state")
def state():
    return jsonify(agent.state())

@app.post("/api/run")
def run():
    body = request.get_json(silent=True) or {}
    return jsonify(agent.run(body.get("ticket_id", "INC-10452")))

@app.post("/api/execute")
def execute():
    return jsonify(agent.execute())

@app.post("/api/feedback")
def feedback():
    body = request.get_json(silent=True) or {}
    return jsonify(agent.process_feedback(body.get("feedback", "")))

@app.post("/api/reset")
def reset():
    agent.reset()
    return jsonify(agent.state())

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
