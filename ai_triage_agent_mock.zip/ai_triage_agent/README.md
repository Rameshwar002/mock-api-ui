# AI Triage Agent — Local Mock

Runnable demo using Python/Flask + HTML/CSS/JS.

Flow:
Jira ticket -> Azure log investigation -> AIA evidence -> historical tickets -> decision -> mock Jira actions -> verification -> human feedback -> validated learned rule.

Real Jira and Azure connections are intentionally mocked behind service adapters. Replace those adapters later without changing the UI/agent workflow.

Run:
1. pip install -r requirements.txt
2. python backend/app.py
3. Open http://127.0.0.1:5000

Main folders:
backend/agents     Agent orchestration
backend/services   Jira/Azure/AIA/history/memory adapters
backend/data       Mock data
frontend           Dashboard
docs               Architecture and production integration notes
