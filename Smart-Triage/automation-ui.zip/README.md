
# Automation UI

## Setup

1. Install Node.js (>=18)

2. Install dependencies:
   npm install

3. Run project:
   npm run dev

4. Open browser:
   http://localhost:5173

## Features
- Dashboard UI
- Execution panel
- Logs terminal
- Control panel

## Next Steps
- Connect backend APIs
- Add WebSocket logs
- Add report viewer
