
export default function AssistantPanel() {
  return (
    <div className="w-80 bg-slate-800 p-6 space-y-4">
      <h3 className="font-bold">Control Center</h3>

      <select className="w-full p-2 bg-slate-700">
        <option>US</option>
        <option>EU</option>
      </select>

      <select className="w-full p-2 bg-slate-700">
        <option>DEV</option>
        <option>PROD</option>
      </select>

      <button className="bg-blue-600 w-full p-3 rounded">
        Start Execution
      </button>
    </div>
  )
}
