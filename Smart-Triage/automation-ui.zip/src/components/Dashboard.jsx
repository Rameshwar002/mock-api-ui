
export default function Dashboard() {
  return (
    <div className="flex-1 p-6 space-y-6 overflow-auto">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      <div className="grid grid-cols-4 gap-4">
        <div className="bg-slate-800 p-4 rounded">Total: 10</div>
        <div className="bg-green-600 p-4 rounded">Pass: 8</div>
        <div className="bg-red-600 p-4 rounded">Fail: 2</div>
        <div className="bg-yellow-500 p-4 rounded">Skip: 0</div>
      </div>

      <div className="bg-slate-800 p-4 rounded">
        <p>Execution Running...</p>
        <div className="bg-gray-700 h-2 mt-2">
          <div className="bg-green-400 h-2 w-3/4"></div>
        </div>
      </div>

      <div className="bg-black text-green-400 p-3 h-40 overflow-auto text-xs">
        <p>> Logs will appear here...</p>
      </div>
    </div>
  )
}
