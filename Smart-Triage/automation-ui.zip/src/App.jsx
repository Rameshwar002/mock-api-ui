
import Dashboard from "./components/Dashboard"
import AssistantPanel from "./components/AssistantPanel"

export default function App() {
  return (
    <div className="flex h-screen bg-slate-900 text-white">
      <Dashboard />
      <AssistantPanel />
    </div>
  )
}
