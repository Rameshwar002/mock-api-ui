import pytest
from db import get_connection

def test_database_url_required(monkeypatch):
    monkeypatch.setattr("db.DATABASE_URL", "")
    with pytest.raises(RuntimeError):
        get_connection()
