import pytest
from sql_validator import validate_readonly_sql

SCHEMA = {"customers": {"columns": [{"name": "customer_id"}]}, "vehicles": {"columns": []}}

def test_select_allowed():
    assert validate_readonly_sql("SELECT customer_id FROM customers", SCHEMA).startswith("SELECT")

def test_update_rejected():
    with pytest.raises(ValueError):
        validate_readonly_sql("UPDATE customers SET region='X'", SCHEMA)

def test_multiple_statements_rejected():
    with pytest.raises(ValueError):
        validate_readonly_sql("SELECT 1; SELECT 2", SCHEMA)

def test_unknown_table_rejected():
    with pytest.raises(ValueError):
        validate_readonly_sql("SELECT * FROM secret_table", SCHEMA)

def test_select_into_rejected():
    with pytest.raises(ValueError):
        validate_readonly_sql("SELECT * INTO new_table FROM customers", SCHEMA)
