from argon2 import PasswordHasher
from auth import authenticate

def test_auth_requires_hash(monkeypatch):
    monkeypatch.setattr("auth.INITIAL_PASSWORD_HASH", "")
    assert authenticate("analyst", "anything")[0] is False

def test_auth_valid_hash(monkeypatch):
    password_hash = PasswordHasher().hash("test-password")
    monkeypatch.setattr("auth.INITIAL_USERNAME", "analyst")
    monkeypatch.setattr("auth.INITIAL_PASSWORD_HASH", password_hash)
    assert authenticate("analyst", "test-password")[0] is True
    assert authenticate("analyst", "wrong")[0] is False
