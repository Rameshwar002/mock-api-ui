from unittest.mock import patch
from agent import generate_sql

def test_generate_sql_uses_ollama_chat():
    fake = {"message": {"content": "SELECT count(*) FROM customers"}}
    with patch("agent._chat", return_value=fake["message"]["content"]) as mocked:
        sql = generate_sql("count customers", "reference", {"customers": {"columns": []}})
    assert sql.startswith("SELECT")
    assert mocked.called
