import os
from dotenv import load_dotenv

load_dotenv()

APP_NAME = "AI Data Analyst"
DATABASE_URL = os.getenv("DATABASE_URL", "")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
INITIAL_USERNAME = os.getenv("INITIAL_USERNAME", "analyst")
INITIAL_PASSWORD_HASH = os.getenv("INITIAL_PASSWORD_HASH", "")
SQL_STATEMENT_TIMEOUT_MS = int(os.getenv("SQL_STATEMENT_TIMEOUT_MS", "10000"))
MAX_RESULT_ROWS = int(os.getenv("MAX_RESULT_ROWS", "1000"))
MAX_SQL_CORRECTION_ATTEMPTS = int(os.getenv("MAX_SQL_CORRECTION_ATTEMPTS", "2"))
SCHEMA_REFERENCE_PATH = os.getenv("SCHEMA_REFERENCE_PATH", "schema_reference.md")
