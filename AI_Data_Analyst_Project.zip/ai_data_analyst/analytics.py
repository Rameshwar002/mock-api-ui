def choose_visualization(data, question=""):
    if data is None or data.empty or len(data.columns) < 2:
        return None
    cols = list(data.columns)
    numeric = [c for c in cols if str(data[c].dtype).startswith(("int", "float"))]
    temporal = [c for c in cols if any(token in c.lower() for token in ("date", "month", "time", "year"))]
    q = question.lower()
    if temporal and numeric:
        return {"kind": "line", "x": temporal[0], "y": numeric[0]}
    if numeric:
        if len(data) <= 8 and any(t in q for t in ("share", "proportion", "percentage", "distribution")):
            return {"kind": "pie", "names": cols[0], "values": numeric[0]}
        return {"kind": "bar", "x": next((c for c in cols if c not in numeric), cols[0]), "y": numeric[0]}
    return None
