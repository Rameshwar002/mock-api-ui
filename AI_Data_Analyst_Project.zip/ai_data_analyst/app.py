import streamlit as st
from config import APP_NAME, MAX_RESULT_ROWS
from auth import authenticate, logout
from db import check_db_connection, execute_readonly_query
from schema_manager import load_schema_reference, get_live_schema
from agent import generate_sql, explain_results
from sql_validator import validate_readonly_sql
from analytics import choose_visualization
from visualizations import render_results

st.set_page_config(page_title=APP_NAME, page_icon="📊", layout="wide", initial_sidebar_state="expanded")

def init_state():
    st.session_state.setdefault("authenticated", False)
    st.session_state.setdefault("username", "")
    st.session_state.setdefault("messages", [])

def login_view():
    st.markdown("""
    <style>
    .stApp {background: radial-gradient(circle at 15% 10%, #17243b 0%, #0b1020 42%, #080b13 100%); color:#edf2ff;}
    .login-card {max-width:520px;margin:7vh auto 0;padding:2rem;border:1px solid #293650;border-radius:20px;background:rgba(15,22,38,.94);}
    .brand {font-size:2.1rem;font-weight:750;letter-spacing:-.04em}
    .muted {color:#9ba9c4}
    </style>
    <div class="login-card">
      <div class="brand">📊 AI Data Analyst</div>
      <p class="muted">Automotive Service Activation Analytics Agent</p>
      <p class="muted">Ask questions. Explore data. Discover insights.</p>
    </div>
    """, unsafe_allow_html=True)
    with st.form("login_form", clear_on_submit=False):
        username = st.text_input("Username", autocomplete="username")
        password = st.text_input("Password", type="password", autocomplete="current-password")
        submitted = st.form_submit_button("Sign in", type="primary", use_container_width=True)
    if submitted:
        ok, message = authenticate(username, password)
        if ok:
            st.session_state.authenticated = True
            st.session_state.username = username.strip()
            st.session_state.messages = []
            st.rerun()
        st.error(message)

def status_dot(ok):
    return "🟢 Connected" if ok else "🔴 Unavailable"

def main_app():
    with st.sidebar:
        st.markdown("# 📊 AI Data Analyst")
        st.caption("Automotive Service Activation Analytics Agent")
        st.write(f"Signed in as **{st.session_state.username}**")
        db_ok, db_message = check_db_connection()
        st.caption(f"PostgreSQL: {status_dot(db_ok)}")
        if not db_ok:
            st.caption(db_message)
        from agent import check_ollama
        ollama_ok, ollama_message = check_ollama()
        st.caption(f"Ollama: {status_dot(ollama_ok)}")
        if not ollama_ok:
            st.caption(ollama_message)
        page = st.radio("Navigation", ["Chat Analytics", "Dashboard", "Data Explorer", "Analytics Reports", "Database Schema", "Settings"])
        st.divider()
        if st.button("Log out", use_container_width=True):
            logout()
            st.rerun()

    st.title("AI Data Analyst")
    st.caption("Automotive Service Activation Analytics Agent")
    if page == "Chat Analytics":
        st.subheader("Chat Analytics")
        st.write("Ask a question about automotive service activations, vehicles, subscriptions, dealers, or provisioning jobs.")
        prompts = [
            "Which services have the highest activation failure rate?",
            "Compare activation success rates across regions.",
            "Show monthly activation trends for the last six months.",
            "What are the most common activation error codes?",
        ]
        cols = st.columns(2)
        for i, prompt in enumerate(prompts):
            if cols[i % 2].button(prompt, key=f"suggest_{i}", use_container_width=True):
                st.session_state.pending_question = prompt
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
                if message.get("sql"):
                    with st.expander("Generated SQL"):
                        st.code(message["sql"], language="sql")
                if message.get("data") is not None:
                    render_results(message["data"], message.get("chart"), message.get("chart_title", "Query results"))
                    st.download_button("Download CSV", message["data"].to_csv(index=False).encode("utf-8"), "query_results.csv", "text/csv", key=f"csv_{message['id']}")
        question = st.chat_input("Ask a question about your data...")
        if st.session_state.get("pending_question"):
            question = st.session_state.pop("pending_question")
        if question:
            st.session_state.messages.append({"role": "user", "content": question})
            with st.chat_message("user"):
                st.markdown(question)
            with st.chat_message("assistant"):
                try:
                    with st.spinner("Understanding question, discovering schema, and generating safe SQL..."):
                        schema_doc = load_schema_reference()
                        live_schema = get_live_schema()
                        sql = generate_sql(question, schema_doc, live_schema)
                        valid_sql = validate_readonly_sql(sql, live_schema)
                        data = execute_readonly_query(valid_sql, max_rows=MAX_RESULT_ROWS)
                        explanation = explain_results(question, valid_sql, data)
                        chart = choose_visualization(data, question)
                    st.markdown(explanation)
                    with st.expander("Generated SQL"):
                        st.code(valid_sql, language="sql")
                    render_results(data, chart, "Query results")
                    if not data.empty:
                        st.download_button("Download CSV", data.to_csv(index=False).encode("utf-8"), "query_results.csv", "text/csv")
                    msg_id = len(st.session_state.messages)
                    st.session_state.messages.append({
                        "role": "assistant", "content": explanation, "sql": valid_sql,
                        "data": data, "chart": chart, "chart_title": "Query results", "id": msg_id
                    })
                    feedback = st.radio("Was this answer useful?", ["No feedback", "Yes", "No — needs improvement"], horizontal=True, key=f"feedback_{msg_id}")
                    if feedback == "No — needs improvement":
                        st.text_area("What should be corrected?", key=f"feedback_text_{msg_id}")
                        st.caption("Feedback is shown in this session only; it does not write to the analytics database.")
                except Exception as exc:
                    safe_message = str(exc)
                    st.error(f"Unable to complete the analysis: {safe_message}")
                    st.session_state.messages.append({"role": "assistant", "content": f"Unable to complete the analysis: {safe_message}"})
    elif page == "Dashboard":
        st.subheader("Live analytics overview")
        st.info("KPIs and charts are generated from live PostgreSQL results. Ask a question in Chat Analytics to explore specific metrics.")
        for col, question in zip(st.columns(3), [
            "Count total service activation records",
            "Count successful and failed activations",
            "Show activation status by region",
        ]):
            with col:
                st.markdown(f"**{question}**")
                if st.button("Analyze", key=f"dash_{question}"):
                    st.session_state.pending_question = question
                    st.session_state.radio_page = "Chat Analytics"
                    st.rerun()
    elif page == "Data Explorer":
        st.subheader("Data Explorer")
        schema = get_live_schema()
        table_names = sorted(schema.keys())
        if not table_names:
            st.warning("No approved tables were discovered. Check the database connection and permissions.")
        else:
            table = st.selectbox("Select table", table_names)
            st.json(schema[table])
            if st.button("Preview table"):
                from db import quote_identifier
                sql = f"SELECT * FROM {quote_identifier('public')}.{quote_identifier(table)} LIMIT {MAX_RESULT_ROWS}"
                data = execute_readonly_query(sql, max_rows=MAX_RESULT_ROWS)
                st.dataframe(data, use_container_width=True)
                st.download_button("Download preview CSV", data.to_csv(index=False).encode("utf-8"), f"{table}.csv", "text/csv")
    elif page == "Analytics Reports":
        st.subheader("Analytics Reports")
        st.write("Use the chat to generate a query-driven report, then export the results as CSV.")
        if st.button("Start a monthly activation report"):
            st.session_state.pending_question = "Show monthly activation counts and success rate for the last 12 months"
            st.rerun()
    elif page == "Database Schema":
        st.subheader("Database Schema")
        st.markdown(load_schema_reference())
        with st.expander("Live PostgreSQL metadata"):
            st.json(get_live_schema())
    elif page == "Settings":
        st.subheader("Settings and service status")
        st.write("Application configuration is loaded from environment variables or `.env`.")
        st.write("PostgreSQL:", status_dot(db_ok))
        st.write("Ollama:", status_dot(ollama_ok))
        st.caption("The analytics connection is configured for read-only access. Database setup scripts must be run manually.")

init_state()
if not st.session_state.authenticated:
    login_view()
else:
    main_app()
