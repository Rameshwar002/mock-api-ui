from pathlib import Path
from config import SCHEMA_REFERENCE_PATH
from db import get_connection

def load_schema_reference():
    path = Path(SCHEMA_REFERENCE_PATH)
    if not path.exists():
        raise FileNotFoundError(f"Schema reference not found: {path.resolve()}")
    return path.read_text(encoding="utf-8")

def get_live_schema():
    query = """
    SELECT c.table_schema, c.table_name, c.column_name, c.data_type,
           c.is_nullable, c.ordinal_position
    FROM information_schema.columns c
    JOIN information_schema.tables t
      ON t.table_schema = c.table_schema AND t.table_name = c.table_name
    WHERE c.table_schema = 'public' AND t.table_type = 'BASE TABLE'
    ORDER BY c.table_name, c.ordinal_position
    """
    with get_connection(readonly=True) as conn:
        rows = conn.execute(query).fetchall()
    schema = {}
    for row in rows:
        table = row["table_name"]
        schema.setdefault(table, {"schema": row["table_schema"], "columns": []})
        schema[table]["columns"].append({
            "name": row["column_name"], "type": row["data_type"],
            "nullable": row["is_nullable"] == "YES"
        })
    # Retrieve PK/FK metadata, not just column names.
    key_query = """
    SELECT tc.table_name, tc.constraint_type, kcu.column_name,
           ccu.table_name AS foreign_table_name, ccu.column_name AS foreign_column_name
    FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
    LEFT JOIN information_schema.constraint_column_usage ccu
      ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
    WHERE tc.table_schema = 'public'
      AND tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY')
    """
    with get_connection(readonly=True) as conn:
        keys = conn.execute(key_query).fetchall()
    for key in keys:
        if key["table_name"] in schema:
            schema[key["table_name"]].setdefault("keys", []).append({
                "type": key["constraint_type"], "column": key["column_name"],
                "references_table": key["foreign_table_name"],
                "references_column": key["foreign_column_name"]
            })
    return schema
