# AI Data Analyst — Schema Reference

## Purpose
This document describes the automotive service activation analytics schema. At runtime, the application compares this reference with live PostgreSQL metadata. Live metadata is authoritative for existing names and types.

## Tables and business meaning

### `customers`
Customer account records. Key: `customer_id`. Includes synthetic customer name/contact, region, and creation timestamp.

### `dealers`
Dealer directory. Key: `dealer_id`. Contains dealer name, city, region, and dealer status.

### `vehicles`
Synthetic vehicle records. Key: `vehicle_id`; `customer_id` references `customers.customer_id`; `dealer_id` references `dealers.dealer_id`. `synthetic_vin` is a generated demonstration identifier and is not a real VIN.

### `service_catalog`
Available services. Key: `service_id`. Describes service name, category, description, and service status.

### `subscriptions`
Vehicle-to-service subscription records. Key: `subscription_id`; `vehicle_id` references `vehicles.vehicle_id`; `service_id` references `service_catalog.service_id`. Dates represent subscription start and expiry.

### `service_activations`
Activation attempts. Key: `activation_id`; `vehicle_id` references `vehicles.vehicle_id`; `service_id` references `service_catalog.service_id`. `requested_at` is request time; `completed_at` is completion time when available. `attempt_number` identifies the attempt. `error_code` and `error_message` describe failure scenarios.

### `activation_events`
Activation event history. Key: `event_id`; `activation_id` references `service_activations.activation_id`. `event_timestamp` is when the event occurred.

### `provisioning_jobs`
Provisioning work related to an activation. Key: `job_id`; `activation_id` references `service_activations.activation_id`. `started_at` and `completed_at` define job timing when present.

## Relationships and joins
- `customers.customer_id = vehicles.customer_id` (one customer to many vehicles).
- `dealers.dealer_id = vehicles.dealer_id` (one dealer to many vehicles).
- `vehicles.vehicle_id = subscriptions.vehicle_id` (one vehicle to many subscriptions).
- `service_catalog.service_id = subscriptions.service_id` (one service to many subscriptions).
- `vehicles.vehicle_id = service_activations.vehicle_id` (one vehicle to many activation attempts).
- `service_catalog.service_id = service_activations.service_id` (one service to many activation attempts).
- `service_activations.activation_id = activation_events.activation_id` (one activation to many events).
- `service_activations.activation_id = provisioning_jobs.activation_id` (one activation to many provisioning jobs).

When joining multiple one-to-many tables, aggregate each child table before joining if necessary to avoid double-counting.

## Business definitions
- Successful activation: `activation_status = 'SUCCESS'`.
- Failed activation: `activation_status = 'FAILED'`.
- Failure rate: failed activations divided by total activation records, multiplied by 100; protect against division by zero.
- Activation duration: `completed_at - requested_at`, where both timestamps are non-null. Confirm status and duration semantics before comparing.
- Pending provisioning jobs: `job_status = 'PENDING'`; older jobs can be assessed with `started_at` or another explicitly specified timestamp.
- Active subscription: `subscription_status = 'ACTIVE'`; expiry dates may further qualify current validity, depending on the question.

## Status values
Seed data uses documented values including activation statuses `SUCCESS`, `FAILED`, `PENDING`; subscription statuses `ACTIVE`, `EXPIRED`, `CANCELLED`; dealer statuses `ACTIVE`, `INACTIVE`; provisioning job statuses `COMPLETED`, `FAILED`, `PENDING`; service status values `ACTIVE`, `INACTIVE`.

## Timestamp guidance
Use PostgreSQL date/time expressions. Monthly trends can use `date_trunc('month', requested_at)`. Durations can use `completed_at - requested_at`. Respect null timestamps.

## Limitations
All records are synthetic demonstration data. They must not be treated as real customers, vehicles, service usage, or operational incidents. Data generation is for development only. Verify status values against the actual schema and seed script.
