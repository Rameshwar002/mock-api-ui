import sqlglot
from sqlglot import exp

ALLOWED_FUNCTIONS = {
    "count", "sum", "avg", "min", "max", "coalesce", "nullif",
    "lower", "upper", "trim", "round", "abs", "date_trunc",
    "extract", "cast", "greatest", "least", "concat", "substring",
    "length", "current_date", "now"
}

def validate_readonly_sql(sql, live_schema):
    if not isinstance(sql, str) or not sql.strip():
        raise ValueError("The model did not return SQL.")
    cleaned = sql.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("sql"):
            cleaned = cleaned[3:].strip()
    try:
        statements = sqlglot.parse(cleaned, read="postgres")
    except Exception as exc:
        raise ValueError(f"SQL parser rejected the query: {exc}") from exc
    if len(statements) != 1 or statements[0] is None:
        raise ValueError("Only one SQL statement is allowed.")
    tree = statements[0]
    if not isinstance(tree, (exp.Select, exp.Subquery, exp.Union, exp.Intersect, exp.Except)):
        raise ValueError("Only a read-only SELECT query is allowed.")
    forbidden = (exp.Insert, exp.Update, exp.Delete, exp.Merge, exp.Create, exp.Alter,
                 exp.Drop, exp.TruncateTable, exp.Command, exp.Transaction, exp.Commit,
                 exp.Rollback, exp.Grant, exp.Revoke)
    if any(isinstance(node, forbidden) for node in tree.walk()):
        raise ValueError("The query contains a prohibited operation.")
    if any(isinstance(node, exp.Into) for node in tree.walk()):
        raise ValueError("SELECT INTO is not permitted.")
    # Restrict referenced tables to live public base tables. CTE aliases are not table refs.
    cte_names = {cte.alias_or_name.lower() for cte in tree.find_all(exp.CTE)}
    allowed_tables = {name.lower() for name in live_schema.keys()}
    for table in tree.find_all(exp.Table):
        if table.name.lower() in cte_names:
            continue
        if table.name.lower() not in allowed_tables:
            raise ValueError(f"Table '{table.name}' is not present in the approved live schema.")
        if table.db and table.db.lower() != "public":
            raise ValueError("Only the public schema is approved.")
        if table.catalog:
            raise ValueError("Cross-database references are not permitted.")
    for func in tree.find_all(exp.Func):
        name = func.sql_name().lower()
        if name and name not in ALLOWED_FUNCTIONS and name not in {"anonymous"}:
            raise ValueError(f"Function '{name}' is not in the SQL function allowlist.")
        if name == "anonymous":
            raise ValueError("Unrecognized functions are not permitted.")
    # Reject wildcard table references outside known schema.
    # Query text length is bounded to reduce parser/LLM abuse.
    if len(cleaned) > 20000:
        raise ValueError("SQL exceeds the permitted length.")
    return cleaned.rstrip(";") + ";"
