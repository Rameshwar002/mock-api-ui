import os
import streamlit as st
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from config import INITIAL_USERNAME, INITIAL_PASSWORD_HASH

_hasher = PasswordHasher()

def authenticate(username: str, password: str):
    expected_user = INITIAL_USERNAME
    password_hash = INITIAL_PASSWORD_HASH
    if not password_hash:
        return False, "Login is not configured. Set INITIAL_PASSWORD_HASH in your .env file."
    if not username or not password:
        return False, "Enter both username and password."
    if username.strip() != expected_user:
        return False, "Invalid username or password."
    try:
        if _hasher.verify(password_hash, password):
            return True, "Authenticated."
    except (VerifyMismatchError, InvalidHashError):
        pass
    return False, "Invalid username or password."

def logout():
    for key in list(st.session_state.keys()):
        del st.session_state[key]
