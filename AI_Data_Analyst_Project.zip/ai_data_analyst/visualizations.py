import streamlit as st
import plotly.express as px

def render_results(data, chart, title="Query results"):
    st.markdown(f"**{title}**")
    if data is None:
        return
    if data.empty:
        st.info("No rows returned.")
        return
    if data.attrs.get("truncated"):
        st.warning("The result exceeded the configured row limit; only the first allowed rows are shown.")
    if chart:
        try:
            if chart["kind"] == "line":
                fig = px.line(data, x=chart["x"], y=chart["y"], markers=True)
            elif chart["kind"] == "pie":
                fig = px.pie(data, names=chart["names"], values=chart["values"], hole=0.35)
            else:
                fig = px.bar(data, x=chart["x"], y=chart["y"])
            fig.update_layout(template="plotly_dark", margin=dict(l=10, r=10, t=35, b=10))
            st.plotly_chart(fig, use_container_width=True)
        except Exception:
            st.caption("A chart could not be generated for this result shape; showing the table instead.")
    st.dataframe(data, use_container_width=True, hide_index=True)
