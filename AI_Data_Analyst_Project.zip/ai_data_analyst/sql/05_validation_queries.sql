-- Run manually to validate the synthetic dataset.
SELECT 'customers' AS table_name, count(*) AS row_count FROM customers
UNION ALL SELECT 'dealers', count(*) FROM dealers
UNION ALL SELECT 'vehicles', count(*) FROM vehicles
UNION ALL SELECT 'service_catalog', count(*) FROM service_catalog
UNION ALL SELECT 'subscriptions', count(*) FROM subscriptions
UNION ALL SELECT 'service_activations', count(*) FROM service_activations
UNION ALL SELECT 'activation_events', count(*) FROM activation_events
UNION ALL SELECT 'provisioning_jobs', count(*) FROM provisioning_jobs;

SELECT activation_status, count(*) FROM service_activations GROUP BY activation_status ORDER BY activation_status;
SELECT region, count(*) FROM customers GROUP BY region ORDER BY region;
SELECT job_status, count(*) FROM provisioning_jobs GROUP BY job_status ORDER BY job_status;
