-- Run manually against the target database. The application never executes setup scripts.
CREATE TABLE IF NOT EXISTS customers (
    customer_id BIGINT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    contact_email TEXT,
    contact_phone TEXT,
    region TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL
);
CREATE TABLE IF NOT EXISTS dealers (
    dealer_id BIGINT PRIMARY KEY,
    dealer_name TEXT NOT NULL,
    city TEXT NOT NULL,
    region TEXT NOT NULL,
    dealer_status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS service_catalog (
    service_id BIGINT PRIMARY KEY,
    service_name TEXT NOT NULL,
    service_category TEXT NOT NULL,
    description TEXT,
    service_status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS vehicles (
    vehicle_id BIGINT PRIMARY KEY,
    synthetic_vin TEXT NOT NULL UNIQUE,
    make TEXT NOT NULL,
    model TEXT NOT NULL,
    model_year INTEGER NOT NULL,
    customer_id BIGINT NOT NULL,
    dealer_id BIGINT NOT NULL,
    vehicle_status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subscriptions (
    subscription_id BIGINT PRIMARY KEY,
    vehicle_id BIGINT NOT NULL,
    service_id BIGINT NOT NULL,
    subscription_status TEXT NOT NULL,
    start_date DATE NOT NULL,
    expiry_date DATE
);
CREATE TABLE IF NOT EXISTS service_activations (
    activation_id BIGINT PRIMARY KEY,
    vehicle_id BIGINT NOT NULL,
    service_id BIGINT NOT NULL,
    activation_status TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ,
    attempt_number INTEGER NOT NULL,
    error_code TEXT,
    error_message TEXT
);
CREATE TABLE IF NOT EXISTS activation_events (
    event_id BIGINT PRIMARY KEY,
    activation_id BIGINT NOT NULL,
    event_type TEXT NOT NULL,
    event_timestamp TIMESTAMPTZ NOT NULL,
    event_description TEXT
);
CREATE TABLE IF NOT EXISTS provisioning_jobs (
    job_id BIGINT PRIMARY KEY,
    activation_id BIGINT NOT NULL,
    job_status TEXT NOT NULL,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT
);
