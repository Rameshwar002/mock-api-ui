-- SQL-generated synthetic dataset. Run after 01, 02, 03 in a fresh database.
-- More than 200 rows are generated for every table. All VIN-like identifiers are explicitly synthetic.
INSERT INTO customers
SELECT g, 'Synthetic Customer ' || g, 'customer' || g || '@example.test',
       '+1-555-' || lpad((g % 10000)::text, 4, '0'),
       (ARRAY['North','South','East','West','Central'])[((g-1)%5)+1],
       now() - ((g % 900)::text || ' days')::interval
FROM generate_series(1, 500) g
ON CONFLICT DO NOTHING;

INSERT INTO dealers
SELECT g, 'Synthetic Dealer ' || g,
       (ARRAY['Pune','Nagpur','Mumbai','Delhi','Bengaluru','Chennai','Hyderabad','Jaipur'])[((g-1)%8)+1],
       (ARRAY['North','South','East','West','Central'])[((g-1)%5)+1],
       CASE WHEN g % 11 = 0 THEN 'INACTIVE' ELSE 'ACTIVE' END
FROM generate_series(1, 240) g
ON CONFLICT DO NOTHING;

INSERT INTO service_catalog
SELECT g, (ARRAY['Remote Start','Vehicle Health','Navigation Plus','Emergency Assist','Smart Charging','Fleet Connect','Security Alert','Roadside Assist'])[((g-1)%8)+1] || ' ' || g,
       (ARRAY['Connectivity','Safety','Navigation','Maintenance','Fleet'])[((g-1)%5)+1],
       'Synthetic description for service ' || g,
       CASE WHEN g % 13 = 0 THEN 'INACTIVE' ELSE 'ACTIVE' END
FROM generate_series(1, 220) g
ON CONFLICT DO NOTHING;

INSERT INTO vehicles
SELECT g, 'SYNTHETIC-VIN-' || lpad(g::text, 8, '0'),
       (ARRAY['Aster','Boreal','Caspian','Dynamo','Everest'])[((g-1)%5)+1],
       (ARRAY['Model-A','Model-B','Model-C','Model-D','Model-E','Model-F'])[((g-1)%6)+1],
       2015 + (g % 11), ((g-1)%500)+1, ((g-1)%240)+1,
       CASE WHEN g % 17 = 0 THEN 'INACTIVE' ELSE 'ACTIVE' END
FROM generate_series(1, 650) g
ON CONFLICT DO NOTHING;

INSERT INTO subscriptions
SELECT g, ((g-1)%650)+1, ((g-1)%220)+1,
       CASE WHEN g % 9 = 0 THEN 'CANCELLED'
            WHEN g % 7 = 0 THEN 'EXPIRED' ELSE 'ACTIVE' END,
       (current_date - ((g%700)+10)),
       CASE WHEN g % 7 = 0 THEN current_date - (g%20)
            ELSE current_date + ((g%500)+30) END
FROM generate_series(1, 900) g
ON CONFLICT DO NOTHING;

INSERT INTO service_activations
SELECT g, ((g-1)%650)+1, ((g-1)%220)+1,
       CASE WHEN g % 10 IN (0,1) THEN 'FAILED'
            WHEN g % 13 = 0 THEN 'PENDING' ELSE 'SUCCESS' END,
       now() - ((g%365)::text || ' days')::interval - ((g%24)::text || ' hours')::interval,
       CASE WHEN g % 13 = 0 THEN NULL
            ELSE now() - ((g%365)::text || ' days')::interval - ((g%24)::text || ' hours')::interval
                 + ((g%45 + 1)::text || ' minutes')::interval END,
       (g%3)+1,
       CASE WHEN g % 10 IN (0,1) THEN (ARRAY['E_TIMEOUT','E_AUTH','E_PROVISION','E_NETWORK'])[((g-1)%4)+1] ELSE NULL END,
       CASE WHEN g % 10 IN (0,1) THEN (ARRAY['Synthetic timeout','Synthetic authorization error','Synthetic provisioning error','Synthetic network error'])[((g-1)%4)+1] ELSE NULL END
FROM generate_series(1, 1400) g
ON CONFLICT DO NOTHING;

INSERT INTO activation_events
SELECT (a.activation_id * 3) + e.n,
       a.activation_id,
       CASE e.n WHEN 0 THEN 'REQUESTED' WHEN 1 THEN 'PROCESSING' ELSE 'COMPLETED' END,
       a.requested_at + (e.n * interval '2 minutes'),
       'Synthetic activation event ' || e.n
FROM service_activations a
CROSS JOIN generate_series(0,2) AS e(n)
ON CONFLICT DO NOTHING;

INSERT INTO provisioning_jobs
SELECT a.activation_id,
       a.activation_id,
       CASE WHEN a.activation_status = 'PENDING' THEN 'PENDING'
            WHEN a.activation_status = 'FAILED' THEN 'FAILED' ELSE 'COMPLETED' END,
       a.requested_at + interval '1 minute',
       CASE WHEN a.activation_status = 'PENDING' THEN NULL ELSE a.requested_at + interval '5 minutes' END,
       CASE WHEN a.activation_status = 'FAILED' THEN coalesce(a.error_message,'Synthetic job failure') ELSE NULL END
FROM service_activations a
ON CONFLICT DO NOTHING;
