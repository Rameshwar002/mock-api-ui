import pandas as pd
import psycopg
from psycopg.rows import dict_row
from config import DATABASE_URL, SQL_STATEMENT_TIMEOUT_MS, MAX_RESULT_ROWS

def get_connection(readonly=True):
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is not configured in .env.")
    conn = psycopg.connect(DATABASE_URL, connect_timeout=5, row_factory=dict_row)
    if readonly:
        conn.execute("SET default_transaction_read_only = on")
        conn.execute("SET statement_timeout = %s", (SQL_STATEMENT_TIMEOUT_MS,))
    return conn

def check_db_connection():
    try:
        with get_connection() as conn:
            conn.execute("SELECT 1")
        return True, "PostgreSQL connection successful."
    except Exception as exc:
        return False, str(exc)

def quote_identifier(name):
    return '"' + str(name).replace('"', '""') + '"'

def execute_readonly_query(sql, max_rows=None):
    row_limit = max_rows or MAX_RESULT_ROWS
    with get_connection(readonly=True) as conn:
        # Transaction is read-only as an additional enforcement layer.
        with conn.transaction():
            conn.execute("SET TRANSACTION READ ONLY")
            cursor = conn.execute(sql)
            rows = cursor.fetchmany(row_limit + 1)
            columns = [desc.name for desc in cursor.description] if cursor.description else []
    truncated = len(rows) > row_limit
    rows = rows[:row_limit]
    frame = pd.DataFrame(rows, columns=columns)
    if truncated:
        frame.attrs["truncated"] = True
    return frame
