# AI Data Analyst
**Automotive Service Activation Analytics Agent**

A local, schema-aware natural-language analytics application built with Streamlit, PostgreSQL, Ollama (Llama 3.2), Pandas, and Plotly. It generates SQL dynamically, validates queries, executes read-only queries, and explains results.

## Requirements
- Windows 10/11
- Python 3.11 or 3.12
- PostgreSQL 15+ and pgAdmin or `psql`
- Ollama for Windows

## 1. Install Ollama and the local model
Install Ollama from its official website, then in PowerShell run:
```powershell
ollama pull llama3.2
ollama list
```
Keep Ollama running on `http://localhost:11434`.

## 2. Create the database and read-only role
Open pgAdmin Query Tool as a database administrator and run the following, changing passwords:
```sql
CREATE DATABASE automotive_analytics;
CREATE USER ai_analyst_readonly WITH PASSWORD 'REPLACE_WITH_STRONG_PASSWORD';
GRANT CONNECT ON DATABASE automotive_analytics TO ai_analyst_readonly;
```
Reconnect to `automotive_analytics` as a database administrator and run:
```sql
GRANT USAGE ON SCHEMA public TO ai_analyst_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO ai_analyst_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO ai_analyst_readonly;
```
Run setup as an administrator, never with the application account.

## 3. Run SQL setup scripts manually
Using pgAdmin, execute these files in order against `automotive_analytics`:
1. `sql/01_create_tables.sql`
2. `sql/02_create_constraints.sql`
3. `sql/03_create_indexes.sql`
4. `sql/04_seed_mock_data.sql`
5. `sql/05_validation_queries.sql`

These scripts are never executed by the application. Run the create/constraint scripts once in a fresh database; constraint script names are not idempotent if rerun.

## 4. Set up Python
Open PowerShell in the project folder:
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```
If PowerShell blocks activation, use `Set-ExecutionPolicy -Scope Process Bypass` for the current terminal, or run `.venv\Scripts\python.exe` directly.

## 5. Configure `.env`
Set `DATABASE_URL` to the local PostgreSQL connection string for the read-only role. Example:
`postgresql://ai_analyst_readonly:YOUR_PASSWORD@localhost:5432/automotive_analytics`

Generate an Argon2 password hash:
```powershell
python -c "from argon2 import PasswordHasher; print(PasswordHasher().hash('Choose-A-Strong-Password'))"
```
Copy the output into `INITIAL_PASSWORD_HASH`. Change `INITIAL_USERNAME` if desired. Do not commit `.env`.

## 6. Start the application
```powershell
python -m streamlit run app.py
```
Streamlit displays a local URL, normally `http://localhost:8501`. Log in with `INITIAL_USERNAME` and the password whose hash you configured.

## Example questions
- Which services have the highest activation failure rate?
- Compare activation success rates across regions.
- Show monthly activation trends for the last six months.
- Which dealers have the highest number of failed activations?
- What are the most common activation error codes?
- Find pending provisioning jobs older than 24 hours.

## Security design
- Authentication precedes all analytics UI and data-access actions.
- Passwords are verified against Argon2 hashes.
- SQL is parsed and limited to one read-only SELECT.
- Live public-schema table metadata is supplied to the model and used to restrict table references.
- Query execution uses a read-only transaction, statement timeout, row limit, and should use a PostgreSQL account with SELECT-only grants.
- Setup and seed SQL files must be run manually.
- Feedback is session-only and never writes to the analytics database.

**Important:** SQL validation is defense-in-depth, not a replacement for database permissions. Use a dedicated read-only PostgreSQL role. Review this prototype before exposing it to untrusted users or production data.

## Troubleshooting
- **`streamlit` not recognized:** activate `.venv`, then use `python -m streamlit run app.py`.
- **PostgreSQL unavailable:** verify the service, port, database name, password, and `DATABASE_URL`.
- **Ollama unavailable:** run `ollama list`, ensure the Ollama app is running, and confirm `OLLAMA_BASE_URL`.
- **Model missing:** run `ollama pull llama3.2` and ensure `OLLAMA_MODEL` matches `ollama list`.
- **Schema reference missing:** run the app from the project root.
- **Permission denied:** grant only required SELECT permissions to the application role.

## Project structure
```text
ai_data_analyst/
├── app.py
├── auth.py
├── agent.py
├── db.py
├── schema_manager.py
├── sql_validator.py
├── analytics.py
├── visualizations.py
├── config.py
├── schema_reference.md
├── sql/
│   ├── 01_create_tables.sql
│   ├── 02_create_constraints.sql
│   ├── 03_create_indexes.sql
│   ├── 04_seed_mock_data.sql
│   └── 05_validation_queries.sql
├── tests/
├── requirements.txt
├── .env.example
└── README.md
```
