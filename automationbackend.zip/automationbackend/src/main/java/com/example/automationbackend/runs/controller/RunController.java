package com.example.automationbackend.runs.controller;

import com.example.automationbackend.runs.model.RunHistory;
import com.example.automationbackend.runs.service.RunService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/runs")
@CrossOrigin(origins = "*")
public class RunController {

    @Autowired
    private RunService runService;

    // POST /api/runs/save
    // Called by chat.html after every test execution completes
    // Body: { username, suite, region, env, totalTests, passed, failed, skipped, durationSeconds }
    @PostMapping("/save")
    public ResponseEntity<?> saveRun(@RequestBody RunHistory run) {
        RunHistory saved = runService.saveRun(run);
        return ResponseEntity.ok(Map.of("status", "saved", "id", saved.getId()));
    }

    // GET /api/runs/all  → admin sees all runs newest first
    @GetMapping("/all")
    public ResponseEntity<?> getAllRuns() {
        return ResponseEntity.ok(runService.getAllRuns());
    }

    // GET /api/runs/my?username=qa  → user sees own runs
    @GetMapping("/my")
    public ResponseEntity<?> getMyRuns(@RequestParam String username) {
        return ResponseEntity.ok(runService.getMyRuns(username));
    }

    // GET /api/runs/stats  → admin analytics charts
    @GetMapping("/stats")
    public ResponseEntity<?> getRunStats() {
        return ResponseEntity.ok(runService.getRunStats());
    }
}