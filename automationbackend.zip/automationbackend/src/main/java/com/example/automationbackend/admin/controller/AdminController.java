package com.example.automationbackend.admin.controller;

import com.example.automationbackend.auth.model.User;
import com.example.automationbackend.auth.repository.UserRepository;
import com.example.automationbackend.registry_module.repository.BugRepository;
import com.example.automationbackend.runs.repository.RunRepository;
import com.example.automationbackend.scriptrequests.repository.ScriptRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired private UserRepository          userRepo;
    @Autowired private BugRepository           bugRepo;
    @Autowired private RunRepository           runRepo;
    @Autowired private ScriptRequestRepository reqRepo;

    // GET /api/admin/users
    // Admin dashboard user table — one row per user with all their stats
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsersWithStats() {
        List<User> users = userRepo.findAll();

        // Pre-aggregate counts
        Map<String, Long> bugsByUser = new LinkedHashMap<>();
        Map<String, Long> reqsByUser = new LinkedHashMap<>();

        bugRepo.countByUser().forEach(r -> bugsByUser.put((String) r[0], (Long) r[1]));
        reqRepo.findAllByOrderByRaisedAtDesc().forEach(req ->
                reqsByUser.merge(req.getRequestedBy(), 1L, Long::sum));

        List<Map<String, Object>> result = new ArrayList<>();

        for (User u : users) {
            String name = u.getUsername();
            var userRuns = runRepo.findByUsernameOrderByRunAtDesc(name);

            int totalTests  = userRuns.stream().mapToInt(r -> r.getTotalTests()).sum();
            int totalPassed = userRuns.stream().mapToInt(r -> r.getPassed()).sum();
            int totalFailed = userRuns.stream().mapToInt(r -> r.getFailed()).sum();

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("name",     name);
            row.put("role",     u.getRole());
            row.put("runs",     userRuns.size());
            row.put("tests",    totalTests);
            row.put("passed",   totalPassed);
            row.put("failed",   totalFailed);
            row.put("bugs",     bugsByUser.getOrDefault(name, 0L));
            row.put("requests", reqsByUser.getOrDefault(name, 0L));
            result.add(row);
        }

        return ResponseEntity.ok(result);
    }

    // GET /api/admin/overview
    // Single call for all KPI cards on the admin dashboard header row
    @GetMapping("/overview")
    public ResponseEntity<?> getOverview() {
        var allRuns     = runRepo.findAllByOrderByRunAtDesc();
        long totalTests = allRuns.stream().mapToLong(r -> r.getTotalTests()).sum();
        long passed     = allRuns.stream().mapToLong(r -> r.getPassed()).sum();
        long failed     = allRuns.stream().mapToLong(r -> r.getFailed()).sum();
        long passRate   = totalTests > 0 ? Math.round((double) passed / totalTests * 100) : 0;
        long openBugs   = bugRepo.findByStatusOrderByUpdatedAtDesc("OPEN").size();
        long openReqs   = reqRepo.findByStatusOrderByRaisedAtDesc("OPEN").size();
        long activeUsers = allRuns.stream().map(r -> r.getUsername()).distinct().count();

        Map<String, Object> overview = new LinkedHashMap<>();
        overview.put("totalRuns",     allRuns.size());
        overview.put("totalTests",    totalTests);
        overview.put("totalPassed",   passed);
        overview.put("totalFailed",   failed);
        overview.put("passRate",      passRate);
        overview.put("totalBugs",     bugRepo.count());
        overview.put("openBugs",      openBugs);
        overview.put("totalRequests", reqRepo.count());
        overview.put("openRequests",  openReqs);
        overview.put("activeUsers",   activeUsers);

        return ResponseEntity.ok(overview);
    }
}