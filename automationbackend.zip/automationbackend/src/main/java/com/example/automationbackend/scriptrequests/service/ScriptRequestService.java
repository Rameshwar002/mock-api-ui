package com.example.automationbackend.scriptrequests.service;

import com.example.automationbackend.scriptrequests.model.ScriptRequest;
import com.example.automationbackend.scriptrequests.repository.ScriptRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScriptRequestService {

    @Autowired
    private ScriptRequestRepository repo;

    public ScriptRequest createRequest(ScriptRequest req) {
        req.setTicketId("REQ-" + (System.currentTimeMillis() % 100000));
        return repo.save(req);
    }

    public List<ScriptRequest> getAll() {
        return repo.findAllByOrderByRaisedAtDesc();
    }

    public List<ScriptRequest> getByUser(String username) {
        return repo.findByRequestedByOrderByRaisedAtDesc(username);
    }

    public List<ScriptRequest> getByStatus(String status) {
        return repo.findByStatusOrderByRaisedAtDesc(status);
    }

    public Optional<ScriptRequest> updateStatus(String ticketId, String newStatus, String updatedBy) {
        return repo.findById(ticketId).map(req -> {
            req.setStatus(newStatus.toUpperCase());
            req.setUpdatedBy(updatedBy);
            return repo.save(req);
        });
    }
}