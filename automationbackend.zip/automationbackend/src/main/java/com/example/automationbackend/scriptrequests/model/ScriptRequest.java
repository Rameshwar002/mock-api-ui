package com.example.automationbackend.scriptrequests.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "script_requests")
public class ScriptRequest {

    @Id
    @Column(length = 30)
    private String ticketId;          // REQ-XXXX

    @Column(nullable = false)
    private String scriptName;        // e.g. payment_gateway_regression

    private String testType;          // Sanity | Regression | Smoke | E2E | Performance
    private String priority;          // Critical | High | Medium | Low
    private String requestedBy;       // tester username

    @Column(columnDefinition = "TEXT")
    private String description;

    private String status;            // OPEN | INPROGRESS | DONE
    private String updatedBy;         // dev who last updated

    private LocalDateTime raisedAt;
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.status    = "OPEN";
        this.raisedAt  = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}