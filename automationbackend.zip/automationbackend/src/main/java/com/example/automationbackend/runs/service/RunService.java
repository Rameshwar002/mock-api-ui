package com.example.automationbackend.runs.service;

import com.example.automationbackend.runs.model.RunHistory;
import com.example.automationbackend.runs.repository.RunRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RunService {

    @Autowired
    private RunRepository runRepository;

    public RunHistory saveRun(RunHistory run) {
        return runRepository.save(run);
    }

    public List<RunHistory> getAllRuns() {
        return runRepository.findAllByOrderByRunAtDesc();
    }

    public List<RunHistory> getMyRuns(String username) {
        return runRepository.findByUsernameOrderByRunAtDesc(username);
    }

    public Map<String, Object> getRunStats() {
        Map<String, Long> byUser   = new LinkedHashMap<>();
        Map<String, Long> bySuite  = new LinkedHashMap<>();
        Map<String, Long> byEnv    = new LinkedHashMap<>();
        Map<String, Long> byRegion = new LinkedHashMap<>();

        runRepository.countByUser()  .forEach(r -> byUser  .put((String) r[0], (Long) r[1]));
        runRepository.countBySuite() .forEach(r -> bySuite .put((String) r[0], (Long) r[1]));
        runRepository.countByEnv()   .forEach(r -> byEnv   .put((String) r[0], (Long) r[1]));
        runRepository.countByRegion().forEach(r -> byRegion.put((String) r[0], (Long) r[1]));

        List<RunHistory> all = runRepository.findAllByOrderByRunAtDesc();
        long totalTests  = all.stream().mapToLong(RunHistory::getTotalTests).sum();
        long totalPassed = all.stream().mapToLong(RunHistory::getPassed).sum();
        long totalFailed = all.stream().mapToLong(RunHistory::getFailed).sum();

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalRuns",   runRepository.count());
        stats.put("totalTests",  totalTests);
        stats.put("totalPassed", totalPassed);
        stats.put("totalFailed", totalFailed);
        stats.put("passRate",    totalTests > 0 ? Math.round((double) totalPassed / totalTests * 100) : 0);
        stats.put("byUser",      byUser);
        stats.put("bySuite",     bySuite);
        stats.put("byEnv",       byEnv);
        stats.put("byRegion",    byRegion);
        return stats;
    }
}