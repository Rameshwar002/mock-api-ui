package com.example.automationbackend.auth.controller;

import com.example.automationbackend.auth.model.User;
import com.example.automationbackend.auth.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {

        Optional<User> userOpt = authService.validateAndReturn(
                credentials.get("username"),
                credentials.get("password")
        );

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            return ResponseEntity.ok(Map.of(
                    "status",   "success",
                    "role",     user.getRole() != null ? user.getRole() : "USER",
                    "username", user.getUsername()
            ));
        }

        return ResponseEntity.status(401).body(Map.of("message", "Invalid Login"));
    }
}