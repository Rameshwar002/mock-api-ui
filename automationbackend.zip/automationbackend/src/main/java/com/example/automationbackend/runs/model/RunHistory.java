package com.example.automationbackend.runs.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "run_history")
public class RunHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;          // who ran the tests
    private String suite;             // Sanity | Regression | Smoke | E2E | Performance
    private String region;            // US | EU | APAC
    private String env;               // PROD | DEV | STAGE | INT | UAT

    private int totalTests;
    private int passed;
    private int failed;
    private int skipped;
    private double durationSeconds;

    private LocalDateTime runAt;

    @PrePersist
    protected void onCreate() {
        this.runAt = LocalDateTime.now();
    }
}