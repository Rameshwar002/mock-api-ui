package com.example.automationbackend.registry_module.controller;
import com.example.automationbackend.registry_module.model.BugRegistry;
import com.example.automationbackend.registry_module.service.RegistryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;


@RestController
@RequestMapping("/api/registry")
@CrossOrigin(origins = "*")
public class RegistryController {

    @Autowired
    private RegistryService registryService;

    @GetMapping("/check")
    public ResponseEntity<?> checkStatus(@RequestParam String testName) {
        return registryService.getExistingBug(testName)
                .map(bug -> {
                    boolean canRaise = "CLOSED".equalsIgnoreCase(bug.getStatus());
                    return ResponseEntity.ok(Map.of(
                            "status",   bug.getStatus(),
                            "raisedBy", bug.getRaisedBy(),
                            "jiraKey",  bug.getJiraKey(),
                            "canRaise", canRaise,
                            "message",  canRaise
                                    ? "Closed. Re-raise allowed."
                                    : "Raised by " + bug.getRaisedBy()
                    ));
                })
                .orElse(ResponseEntity.ok(Map.of("canRaise", true, "status", "NEW")));
    }

    // GET /api/registry/my-history?username=qa
    @GetMapping("/my-history")
    public ResponseEntity<?> getMyHistory(@RequestParam String username) {
        return ResponseEntity.ok(registryService.getUserHistory(username));
    }

    // POST /api/registry/raise?username=qa
    // Body: { testCaseName, env, description, suite, region, priority }
    @PostMapping("/raise")
    public ResponseEntity<?> raiseBug(
            @RequestBody Map<String, String> bug,
            @RequestParam String username) {

        String testCaseName = bug.get("testCaseName");
        String env          = bug.get("env");

        Optional<BugRegistry> existing = registryService.findExistingOpenBug(testCaseName, env);
        if (existing.isPresent()) {
            BugRegistry ex = existing.get();
            return ResponseEntity.ok(Map.of(
                    "status",  "EXISTS",
                    "message", "Bug already exists",
                    "jiraKey", ex.getJiraKey(),
                    "user",    ex.getRaisedBy(),
                    "env",     ex.getEnv()
            ));
        }

        BugRegistry entity = new BugRegistry();
        entity.setTestCaseName(testCaseName);
        entity.setErrorMessage(bug.get("description"));
        entity.setEnv(env);
        entity.setSuite(bug.getOrDefault("suite",    "Unknown"));
        entity.setRegion(bug.getOrDefault("region",  "Unknown"));
        entity.setPriority(bug.getOrDefault("priority", "Medium"));
        String jiraKey = "NEX-" + System.currentTimeMillis();
        entity.setJiraKey(jiraKey);
        entity.setStatus("OPEN");

        registryService.saveBug(entity, username);

        return ResponseEntity.ok(Map.of(
                "status",  "CREATED",
                "message", "Bug Raised Successfully",
                "jiraKey", jiraKey,
                "user",    username,
                "env",     env
        ));
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllBugs(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String env,
            @RequestParam(required = false) String priority) {

        if (status   != null) return ResponseEntity.ok(registryService.getByStatus(status));
        if (env      != null) return ResponseEntity.ok(registryService.getByEnv(env));
        if (priority != null) return ResponseEntity.ok(registryService.getByPriority(priority));
        return ResponseEntity.ok(registryService.getAllBugs());
    }

    // GET /api/registry/assigned?username=dev → dev portal: bugs assigned to me
    @GetMapping("/assigned")
    public ResponseEntity<?> getAssignedBugs(@RequestParam String username) {
        return ResponseEntity.ok(registryService.getAssignedBugs(username));
    }

    // PATCH /api/registry/close?testName=Login_Validation_Flow → mark CLOSED
    @PatchMapping("/close")
    public ResponseEntity<?> closeBug(@RequestParam String testName) {
        return registryService.closeBug(testName)
                .map(bug -> ResponseEntity.ok(Map.of(
                        "status",  "CLOSED",
                        "jiraKey", bug.getJiraKey(),
                        "message", "Bug marked as closed"
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    // PATCH /api/registry/assign?testName=Login_Validation_Flow&assignTo=dev
    @PatchMapping("/assign")
    public ResponseEntity<?> assignBug(
            @RequestParam String testName,
            @RequestParam String assignTo) {
        return registryService.assignBug(testName, assignTo)
                .map(bug -> ResponseEntity.ok(Map.of(
                        "jiraKey",    bug.getJiraKey(),
                        "assignedTo", bug.getAssignedTo(),
                        "message",    "Bug assigned to " + assignTo
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    // GET /api/registry/stats → admin analytics
    @GetMapping("/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(registryService.getStats());
    }
}