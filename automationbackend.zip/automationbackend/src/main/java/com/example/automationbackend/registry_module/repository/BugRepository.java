package com.example.automationbackend.registry_module.repository;

import com.example.automationbackend.registry_module.model.BugRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BugRepository extends JpaRepository<BugRegistry, String> {

    // Tester: own history newest first
    List<BugRegistry> findByRaisedByOrderByUpdatedAtDesc(String raisedBy);

    // Dedup check — same test + env + OPEN
    Optional<BugRegistry> findByTestCaseNameAndEnvAndStatus(
            String testCaseName, String env, String status);

    // Admin: all bugs newest first
    List<BugRegistry> findAllByOrderByUpdatedAtDesc();

    // Admin: filter by status
    List<BugRegistry> findByStatusOrderByUpdatedAtDesc(String status);

    // Admin: filter by env
    List<BugRegistry> findByEnvOrderByUpdatedAtDesc(String env);

    // Admin: filter by priority
    List<BugRegistry> findByPriorityOrderByUpdatedAtDesc(String priority);

    // Dev: bugs assigned to this developer
    List<BugRegistry> findByAssignedToOrderByUpdatedAtDesc(String assignedTo);

    // Admin stats: count bugs grouped by user
    @Query("SELECT b.raisedBy, COUNT(b) FROM BugRegistry b GROUP BY b.raisedBy")
    List<Object[]> countByUser();

    // Admin stats: count bugs grouped by status
    @Query("SELECT b.status, COUNT(b) FROM BugRegistry b GROUP BY b.status")
    List<Object[]> countByStatus();

    // Admin stats: count bugs grouped by priority
    @Query("SELECT b.priority, COUNT(b) FROM BugRegistry b GROUP BY b.priority")
    List<Object[]> countByPriority();

    // Admin stats: count bugs grouped by suite
    @Query("SELECT b.suite, COUNT(b) FROM BugRegistry b GROUP BY b.suite")
    List<Object[]> countBySuite();
}