package com.example.automationbackend.scriptrequests.repository;

import com.example.automationbackend.scriptrequests.model.ScriptRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ScriptRequestRepository extends JpaRepository<ScriptRequest, String> {

    List<ScriptRequest> findAllByOrderByRaisedAtDesc();

    List<ScriptRequest> findByRequestedByOrderByRaisedAtDesc(String requestedBy);

    List<ScriptRequest> findByStatusOrderByRaisedAtDesc(String status);
}