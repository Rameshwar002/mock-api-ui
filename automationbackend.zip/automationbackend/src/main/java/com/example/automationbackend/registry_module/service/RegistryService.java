package com.example.automationbackend.registry_module.service;

import com.example.automationbackend.registry_module.model.BugRegistry;
import com.example.automationbackend.registry_module.repository.BugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RegistryService {

    @Autowired
    private BugRepository bugRepository;

    // ── EXISTING (unchanged) ──────────────────────────────────────────────────

    public Optional<BugRegistry> getExistingBug(String testName) {
        return bugRepository.findById(testName);
    }

    public List<BugRegistry> getUserHistory(String username) {
        return bugRepository.findByRaisedByOrderByUpdatedAtDesc(username);
    }

    public void saveBug(BugRegistry bug, String username) {
        bug.setRaisedBy(username);
        bugRepository.save(bug);
    }

    public Optional<BugRegistry> findExistingOpenBug(String testCaseName, String env) {
        return bugRepository.findByTestCaseNameAndEnvAndStatus(testCaseName, env, "OPEN");
    }

    // ── NEW ───────────────────────────────────────────────────────────────────

    // Admin: all bugs
    public List<BugRegistry> getAllBugs() {
        return bugRepository.findAllByOrderByUpdatedAtDesc();
    }

    // Admin: filter
    public List<BugRegistry> getByStatus(String status) {
        return bugRepository.findByStatusOrderByUpdatedAtDesc(status);
    }

    public List<BugRegistry> getByEnv(String env) {
        return bugRepository.findByEnvOrderByUpdatedAtDesc(env);
    }

    public List<BugRegistry> getByPriority(String priority) {
        return bugRepository.findByPriorityOrderByUpdatedAtDesc(priority);
    }

    // Dev: assigned to me
    public List<BugRegistry> getAssignedBugs(String devUsername) {
        return bugRepository.findByAssignedToOrderByUpdatedAtDesc(devUsername);
    }

    // Admin: close a bug
    public Optional<BugRegistry> closeBug(String testCaseName) {
        return bugRepository.findById(testCaseName).map(bug -> {
            bug.setStatus("CLOSED");
            return bugRepository.save(bug);
        });
    }

    // Admin: assign a bug to a dev
    public Optional<BugRegistry> assignBug(String testCaseName, String devUsername) {
        return bugRepository.findById(testCaseName).map(bug -> {
            bug.setAssignedTo(devUsername);
            return bugRepository.save(bug);
        });
    }

    // Admin: stats for analytics charts
    public Map<String, Object> getStats() {
        Map<String, Long> byUser     = new LinkedHashMap<>();
        Map<String, Long> byStatus   = new LinkedHashMap<>();
        Map<String, Long> byPriority = new LinkedHashMap<>();
        Map<String, Long> bySuite    = new LinkedHashMap<>();

        bugRepository.countByUser()    .forEach(r -> byUser    .put((String) r[0], (Long) r[1]));
        bugRepository.countByStatus()  .forEach(r -> byStatus  .put((String) r[0], (Long) r[1]));
        bugRepository.countByPriority().forEach(r -> byPriority.put((String) r[0], (Long) r[1]));
        bugRepository.countBySuite()   .forEach(r -> bySuite   .put((String) r[0], (Long) r[1]));

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total",      bugRepository.count());
        stats.put("byUser",     byUser);
        stats.put("byStatus",   byStatus);
        stats.put("byPriority", byPriority);
        stats.put("bySuite",    bySuite);
        return stats;
    }
}