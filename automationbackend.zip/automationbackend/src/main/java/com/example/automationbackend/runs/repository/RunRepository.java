package com.example.automationbackend.runs.repository;

import com.example.automationbackend.runs.model.RunHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RunRepository extends JpaRepository<RunHistory, Long> {

    // User's own runs
    List<RunHistory> findByUsernameOrderByRunAtDesc(String username);

    // All runs (admin)
    List<RunHistory> findAllByOrderByRunAtDesc();

    // Stats queries
    @Query("SELECT r.username, COUNT(r) FROM RunHistory r GROUP BY r.username")
    List<Object[]> countByUser();

    @Query("SELECT r.suite, COUNT(r) FROM RunHistory r GROUP BY r.suite")
    List<Object[]> countBySuite();

    @Query("SELECT r.env, COUNT(r) FROM RunHistory r GROUP BY r.env")
    List<Object[]> countByEnv();

    @Query("SELECT r.region, COUNT(r) FROM RunHistory r GROUP BY r.region")
    List<Object[]> countByRegion();
}