package com.example.automationbackend.auth.service;

import com.example.automationbackend.auth.model.User;
import com.example.automationbackend.auth.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    // Keep original — still works if anything else calls it
    public boolean validate(String username, String password) {
        return validateAndReturn(username, password).isPresent();
    }

    // New — returns the full User so controller can read role from DB
    public Optional<User> validateAndReturn(String username, String password) {
        return userRepository.findByUsername(username)
                .filter(user -> user.getPassword().equals(password));
    }
}