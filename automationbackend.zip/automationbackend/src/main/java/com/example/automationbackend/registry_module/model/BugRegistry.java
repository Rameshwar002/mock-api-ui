package com.example.automationbackend.registry_module.model;

import lombok.Data;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bug_registry")
public class BugRegistry {

    @Id
    @Column(length = 500)
    private String testCaseName;     // Robot Framework test name — unique key

    private String jiraKey;          // NEX-XXXX
    private String status;           // OPEN | CLOSED
    private String raisedBy;         // tester username
    private String assignedTo;       // dev username (optional)
    private String env;              // PROD | DEV | STAGE | INT | UAT
    private String region;           // US | EU | APAC
    private String suite;            // Sanity | Regression | Smoke | E2E | Performance
    private String priority;         // Critical | High | Medium | Low

    @Column(columnDefinition = "TEXT")
    private String errorMessage;

    private LocalDateTime raisedAt;
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.raisedAt  = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}