package com.example.automationbackend.scriptrequests.controller;

import com.example.automationbackend.scriptrequests.model.ScriptRequest;
import com.example.automationbackend.scriptrequests.service.ScriptRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/script-requests")
@CrossOrigin(origins = "*")
public class ScriptRequestController {

    @Autowired
    private ScriptRequestService service;

    // POST /api/script-requests
    // Called by chat.html when tester raises a script request
    // Body: { scriptName, testType, priority, requestedBy, description }
    @PostMapping
    public ResponseEntity<?> createRequest(@RequestBody ScriptRequest req) {
        ScriptRequest saved = service.createRequest(req);
        return ResponseEntity.ok(Map.of(
                "status",      "created",
                "ticketId",    saved.getTicketId(),
                "scriptName",  saved.getScriptName(),
                "requestedBy", saved.getRequestedBy()
        ));
    }

    // GET /api/script-requests           → admin + dev see all
    // GET /api/script-requests?user=qa   → tester sees only their own
    // GET /api/script-requests?status=OPEN → filter by status
    @GetMapping
    public ResponseEntity<?> getRequests(
            @RequestParam(required = false) String user,
            @RequestParam(required = false) String status) {

        if (user   != null) return ResponseEntity.ok(service.getByUser(user));
        if (status != null) return ResponseEntity.ok(service.getByStatus(status));
        return ResponseEntity.ok(service.getAll());
    }

    // PATCH /api/script-requests/{ticketId}
    // Called by dev.html when dev updates status
    // Body: { status: "INPROGRESS", updatedBy: "dev" }
    @PatchMapping("/{ticketId}")
    public ResponseEntity<?> updateStatus(
            @PathVariable String ticketId,
            @RequestBody Map<String, String> body) {

        return service.updateStatus(ticketId, body.get("status"), body.getOrDefault("updatedBy", "unknown"))
                .map(req -> ResponseEntity.ok(Map.of(
                        "ticketId",  req.getTicketId(),
                        "status",    req.getStatus(),
                        "updatedBy", req.getUpdatedBy()
                )))
                .orElse(ResponseEntity.notFound().build());
    }
}