from datetime import datetime, timezone

class TriageOrchestrator:
    def __init__(self, jira, azure, aia, history, memory):
        self.jira, self.azure, self.aia = jira, azure, aia
        self.history, self.memory = history, memory
        self.last = None

    def now(self):
        return datetime.now(timezone.utc).strftime("%H:%M:%S")

    def run(self, ticket_id):
        ticket = self.jira.get_ticket(ticket_id)
        logs = self.azure.search(ticket)
        docs = self.aia.search(ticket)
        similar = self.history.search(ticket)
        rules = self.memory.match(ticket)

        team = rules[0]["team"] if rules else "Payment Platform Team"
        rule_used = rules[0]["id"] if rules else None

        self.last = {
            "ticket": ticket,
            "logs": logs,
            "aia": docs,
            "similar": similar,
            "rules": self.memory.all(),
            "evidence": [
                {"type":"Jira", "text": f'{ticket["key"]}: {ticket["summary"]}'},
                {"type":"Azure Logs", "text": logs["finding"]},
                {"type":"AIA", "text": docs["finding"]},
                {"type":"History", "text": f"{len(similar)} similar tickets found"},
            ],
            "decision": {
                "category":"Production Incident",
                "component":ticket["component"],
                "environment":ticket["environment"],
                "severity":"HIGH",
                "priority":"P1",
                "team":team,
                "confidence":97 if rule_used else 93,
                "root_cause":logs["finding"],
                "rule_used":rule_used
            },
            "activity":[
                ("done","Ticket received from Jira"),
                ("done","Ticket fields and context extracted"),
                ("done","Azure Log Analytics search completed"),
                ("done","AIA/architecture evidence checked"),
                ("done","Historical ticket search completed"),
                ("done","Triage decision generated")
            ],
            "status":"READY_TO_EXECUTE",
            "feedback":None,
            "updated_at":self.now()
        }
        return self.last

    def execute(self):
        if not self.last:
            return {"error":"Run the agent first."}
        d, t = self.last["decision"], self.last["ticket"]
        self.last["actions"] = [
            self.jira.mock_update(t["key"],"component",d["component"]),
            self.jira.mock_update(t["key"],"priority",d["priority"]),
            self.jira.mock_update(t["key"],"severity",d["severity"]),
            self.jira.mock_assign(t["key"],d["team"]),
            self.jira.mock_comment(t["key"],
                f'AI triage completed. Root cause: {d["root_cause"]}. Confidence: {d["confidence"]}%.')
        ]
        self.last["activity"] += [
            ("done","Mock Jira fields updated"),
            ("done","Mock Jira assignment completed"),
            ("done","Mock Jira triage comment added"),
            ("done","Post-action verification completed")
        ]
        self.last["status"]="COMPLETED"
        return self.last

    def process_feedback(self, feedback):
        if not self.last:
            return {"error":"Run the agent first."}
        if not feedback.strip():
            return {"error":"Feedback cannot be empty."}

        valid = "apac payments" in feedback.lower() and "payment" in feedback.lower()
        if valid:
            rule = self.memory.learn({
                "condition":"APAC + Payment Gateway",
                "team":"APAC Payments Team",
                "reason":feedback,
                "source":"validated human feedback"
            })
            self.last["feedback"]={"text":feedback,"validated":True,"rule":rule}
            self.last["status"]="LEARNED"
            self.last["activity"] += [
                ("done","Human feedback received"),
                ("done","Feedback checked against mock ownership evidence"),
                ("done",f'Learned rule {rule["id"]}')
            ]
        else:
            self.last["feedback"]={"text":feedback,"validated":False,"rule":None}
            self.last["status"]="FEEDBACK_REVIEW"
            self.last["activity"].append(("warn","Feedback needs additional evidence before changing a rule"))
        self.last["rules"]=self.memory.all()
        return self.last

    def state(self):
        return self.last or {"status":"IDLE","activity":[],"rules":self.memory.all()}

    def reset(self):
        self.last=None
