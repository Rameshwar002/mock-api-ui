import json

class JiraService:
    # MOCK adapter. Replace methods with Jira REST calls in production.
    def __init__(self, path):
        self.tickets=json.loads(path.read_text())

    def get_ticket(self,key):
        return next(t for t in self.tickets if t["key"]==key)

    def mock_update(self,key,field,value):
        return {"system":"JIRA (MOCK)","action":"UPDATE_FIELD","ticket":key,"field":field,"value":value,"result":"SUCCESS"}

    def mock_assign(self,key,team):
        return {"system":"JIRA (MOCK)","action":"ASSIGN","ticket":key,"team":team,"result":"SUCCESS"}

    def mock_comment(self,key,comment):
        return {"system":"JIRA (MOCK)","action":"ADD_COMMENT","ticket":key,"comment":comment,"result":"SUCCESS"}
