import json
from pathlib import Path
from datetime import datetime, timezone

class MemoryService:
    def __init__(self,path):
        self.path=Path(path)
        self.rules=json.loads(self.path.read_text())

    def match(self,ticket):
        return [r for r in self.rules if "APAC" in r["condition"] and ticket["environment"]=="APAC PROD" and ticket["component"]=="Payment Gateway"]

    def learn(self,data):
        rule={"id":f"RULE-{len(self.rules)+140}",**data,
              "created_at":datetime.now(timezone.utc).strftime("%Y-%m-%d")}
        self.rules.append(rule)
        self.path.write_text(json.dumps(self.rules,indent=2))
        return rule

    def all(self): return self.rules
