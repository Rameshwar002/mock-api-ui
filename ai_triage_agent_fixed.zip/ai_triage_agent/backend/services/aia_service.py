import json
class AIAService:
    def __init__(self,path): self.docs=json.loads(path.read_text())
    def search(self,ticket):
        matches=[d for d in self.docs if d["component"].lower()==ticket["component"].lower()]
        return {"finding":matches[0]["finding"] if matches else "No AIA evidence found.","documents":matches}
