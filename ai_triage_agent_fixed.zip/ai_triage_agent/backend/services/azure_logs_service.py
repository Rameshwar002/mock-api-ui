import json

class AzureLogsService:
    # MOCK Azure Log Analytics adapter. Replace search() with Azure/KQL integration.
    def __init__(self,path):
        self.logs=json.loads(path.read_text())

    def search(self,ticket):
        rows=[x for x in self.logs if x["ticket"]==ticket["key"] or x.get("correlation_id")==ticket.get("correlation_id")]
        return {
            "finding":"Database timeout caused Payment Gateway failure." if rows else "No matching logs found.",
            "rows":rows
        }
