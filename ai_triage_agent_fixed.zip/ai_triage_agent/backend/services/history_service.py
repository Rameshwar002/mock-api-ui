import json
class HistoryService:
    def __init__(self,path): self.items=json.loads(path.read_text())
    def search(self,ticket):
        return [x for x in self.items if x["component"].lower()==ticket["component"].lower() and x["environment"].lower()==ticket["environment"].lower()]
