from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from agents.orchestrator import TriageOrchestrator
from services.jira_service import JiraService
from services.azure_logs_service import AzureLogsService
from services.aia_service import AIAService
from services.history_service import HistoryService
from services.memory_service import MemoryService


# Resolve paths from this file so the application works regardless of
# whether it is started from the project root or the backend directory.
BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BACKEND_DIR.parent
FRONTEND_DIR = PROJECT_DIR / "frontend"
DATA_DIR = BACKEND_DIR / "data"

app = Flask(__name__, static_folder=None)

agent = TriageOrchestrator(
    JiraService(DATA_DIR / "tickets.json"),
    AzureLogsService(DATA_DIR / "azure_logs.json"),
    AIAService(DATA_DIR / "aia_documents.json"),
    HistoryService(DATA_DIR / "historical_tickets.json"),
    MemoryService(DATA_DIR / "rules.json"),
)


# ---------------------------------------------------------------------------
# Frontend routes
# ---------------------------------------------------------------------------

@app.get("/")
def index():
    return send_from_directory(str(FRONTEND_DIR), "index.html")


@app.get("/styles.css")
def styles():
    return send_from_directory(str(FRONTEND_DIR), "styles.css")


@app.get("/app.js")
def javascript():
    return send_from_directory(str(FRONTEND_DIR), "app.js")


# ---------------------------------------------------------------------------
# API routes
# ---------------------------------------------------------------------------

@app.get("/api/health")
def health():
    return jsonify(
        {
            "status": "UP",
            "service": "AI Triage Agent",
            "frontend_exists": FRONTEND_DIR.exists(),
            "frontend_path": str(FRONTEND_DIR),
            "port": 8080,
        }
    )


@app.get("/api/state")
def state():
    return jsonify(agent.state())


@app.post("/api/run")
def run():
    body = request.get_json(silent=True) or {}
    ticket_id = body.get("ticket_id", "INC-10452")

    try:
        return jsonify(agent.run(ticket_id))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/execute")
def execute():
    try:
        result = agent.execute()
        if isinstance(result, dict) and result.get("error"):
            return jsonify(result), 400
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/feedback")
def feedback():
    body = request.get_json(silent=True) or {}
    feedback_text = body.get("feedback", "")

    try:
        result = agent.process_feedback(feedback_text)
        if isinstance(result, dict) and result.get("error"):
            return jsonify(result), 400
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/reset")
def reset():
    agent.reset()
    return jsonify(agent.state())


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=" * 64)
    print("AI TRIAGE AGENT")
    print("=" * 64)
    print(f"Project : {PROJECT_DIR}")
    print(f"Backend : {BACKEND_DIR}")
    print(f"Frontend: {FRONTEND_DIR}")
    print(f"Exists  : {FRONTEND_DIR.exists()}")
    print()
    print("Open: http://127.0.0.1:8080")
    print("Health: http://127.0.0.1:8080/api/health")
    print("=" * 64)

    app.run(
        host="127.0.0.1",
        port=8080,
        debug=True,
    )
