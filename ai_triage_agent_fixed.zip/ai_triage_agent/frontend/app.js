const $=x=>document.getElementById(x);
async function api(u,o={}){return (await fetch(u,{headers:{"Content-Type":"application/json"},...o})).json()}
function render(s){
$("ticket").textContent=s.ticket?.key||"—";$("status").textContent=s.status||"IDLE";$("confidence").textContent=s.decision?s.decision.confidence+"%":"—";$("rule").textContent=s.decision?.rule_used||"None";
$("activity").innerHTML=(s.activity||[]).map(x=>`<div class="event">${x[1]}</div>`).join("");
let d=s.decision;$("decision").innerHTML=d?["category","component","environment","severity","priority","team","root_cause","confidence"].map(k=>`<div class="row"><label>${k}</label><b>${d[k]}${k=="confidence"?"%":""}</b></div>`).join(""):"Run the agent.";
$("evidence").innerHTML=(s.evidence||[]).map(x=>`<div class="ev"><b>${x.type}</b>${x.text}</div>`).join("");
$("actions").innerHTML=(s.actions||[]).map(x=>`<div class="ev"><b>${x.action}</b>${x.ticket} → ${x.team||x.value||x.comment||""}<br>${x.result}</div>`).join("")||"No actions yet.";
$("learning").innerHTML=s.feedback?.validated?`<div class="learn">✓ Feedback validated. Learned <b>${s.feedback.rule.id}</b>: ${s.feedback.rule.condition} → ${s.feedback.rule.team}</div>`:"";
$("rules").innerHTML=(s.rules||[]).map(r=>`<div class="rule"><b>${r.id}</b> — ${r.condition} → <code>${r.team}</code><br>${r.reason||""}</div>`).join("")||"No learned rules yet.";
}
$("run").onclick=async()=>render(await api("/api/run",{method:"POST",body:JSON.stringify({ticket_id:"INC-10452"})}));
$("execute").onclick=async()=>render(await api("/api/execute",{method:"POST"}));
$("send").onclick=async()=>{let v=$("feedback").value.trim();if(v)render(await api("/api/feedback",{method:"POST",body:JSON.stringify({feedback:v})}));$("feedback").value=""};
$("reset").onclick=async()=>render(await api("/api/reset",{method:"POST"}));
api("/api/state").then(render);
