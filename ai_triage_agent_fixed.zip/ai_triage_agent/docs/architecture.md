# Architecture

Jira Ticket -> Orchestrator -> Evidence Collection -> Decision -> Action -> Verification -> Human Feedback -> Rule Validation -> Learned Memory.

Evidence sources:
- Jira ticket
- Azure Log Analytics
- AIA/architecture documents
- Historical tickets
- Structured learned rules

Production Jira adapter should support get issue, update fields, comment, assign and link issues.
Production Azure adapter should authenticate, run parameterized KQL, filter by time/correlation ID and return normalized evidence.
Never allow the LLM to invent logs or document facts.

Feedback must be validated against evidence before becoming a reusable rule.
