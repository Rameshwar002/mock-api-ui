# AI Triage Agent — Local Mock

Runnable demo using Python/Flask + HTML/CSS/JS.

Flow:
Jira ticket -> Azure log investigation -> AIA evidence -> historical tickets -> decision -> mock Jira actions -> verification -> human feedback -> validated learned rule.

Real Jira and Azure connections are intentionally mocked behind service adapters. Replace those adapters later without changing the UI/agent workflow.

Run:
1. pip install -r requirements.txt
2. python backend/app.py
3. Open http://127.0.0.1:8080

Main folders:
backend/agents     Agent orchestration
backend/services   Jira/Azure/AIA/history/memory adapters
backend/data       Mock data
frontend           Dashboard
docs               Architecture and production integration notes


## Frontend routing

Flask serves the frontend directly from the `frontend/` folder. The following routes are explicitly available:

- `/` -> `frontend/index.html`
- `/styles.css` -> `frontend/styles.css`
- `/app.js` -> `frontend/app.js`
- `/api/*` -> backend APIs

This avoids 404 errors caused by opening `index.html` directly or relying on Flask's default `templates/` and `static/` folders.

## Quick verification

After starting the app, check:

- http://127.0.0.1:8080/
- http://127.0.0.1:8080/styles.css
- http://127.0.0.1:8080/app.js
- http://127.0.0.1:8080/api/health
