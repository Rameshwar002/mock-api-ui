package com.example.automationbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomationbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
