package com.example.automationbackend.registry_module.model;

import lombok.Data;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bug_registry")
public class BugRegistry {
    @Id
    @Column(length = 500)
    private String testCaseName;    // Unique Robot Test Name

    private String jiraKey;
    private String status;          // OPEN or CLOSED
    private String raisedBy;        // From Login Session
    private String env;             // INT, PROD, etc.

    @Column(columnDefinition = "TEXT")
    private String errorMessage;    // Why it failed

    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}