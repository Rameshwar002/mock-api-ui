package com.example.automationbackend.registry_module.service;

import com.example.automationbackend.registry_module.model.BugRegistry;
import com.example.automationbackend.registry_module.repository.BugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RegistryService {

    @Autowired
    private BugRepository bugRepository;

    // Check if anyone raised this bug
    public Optional<BugRegistry> getExistingBug(String testName) {
        return bugRepository.findById(testName);
    }

    // Get personal history for the logged-in user
    public List<BugRegistry> getUserHistory(String username) {
        return bugRepository.findByRaisedByOrderByUpdatedAtDesc(username);
    }

    public void saveBug(BugRegistry bug, String username) {
        bug.setRaisedBy(username);
        bugRepository.save(bug);
    }
}