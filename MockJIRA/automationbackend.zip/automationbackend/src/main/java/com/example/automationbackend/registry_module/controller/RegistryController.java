package com.example.automationbackend.registry_module.controller;
import com.example.automationbackend.registry_module.model.BugRegistry;
import com.example.automationbackend.registry_module.service.RegistryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping("/api/registry")
@CrossOrigin(origins = "*")
public class RegistryController {

    @Autowired
    private RegistryService registryService;

    // 1. Check Bug Status (Validates with Test Case Name)
    @GetMapping("/check")
    public ResponseEntity<?> checkStatus(@RequestParam String testName) {
        return registryService.getExistingBug(testName)
                .map(bug -> {
                    boolean canRaise = "CLOSED".equalsIgnoreCase(bug.getStatus());
                    return ResponseEntity.ok(Map.of(
                            "status", bug.getStatus(),
                            "raisedBy", bug.getRaisedBy(),
                            "jiraKey", bug.getJiraKey(),
                            "canRaise", canRaise,
                            "message", canRaise ? "Closed. Re-raise allowed." : "Raised by " + bug.getRaisedBy()
                    ));
                })
                .orElse(ResponseEntity.ok(Map.of("canRaise", true, "status", "NEW")));
    }

    // 2. My History (Bugs raised by THIS logged-in user)
    @GetMapping("/my-history")
    public ResponseEntity<?> getMyHistory(@RequestParam String username) {
        return ResponseEntity.ok(registryService.getUserHistory(username));
    }

    // 3. Raise Bug (Links to logged-in user)
    @PostMapping("/raise")
    public ResponseEntity<?> raiseBug(@RequestBody BugRegistry bug, @RequestParam String username) {
        registryService.saveBug(bug, username);
        return ResponseEntity.ok(Map.of("message", "Success"));
    }
}