package com.example.automationbackend.auth.controller;

import com.example.automationbackend.auth.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        boolean isValid = authService.validate(
                credentials.get("username"),
                credentials.get("password")
        );

        if (isValid) {
            return ResponseEntity.ok(Map.of("status", "success", "role", "ADMIN"));
        }
        return ResponseEntity.status(401).body(Map.of("message", "Invalid Login"));
    }
}