package com.example.automationbackend.registry_module.repository;

import com.example.automationbackend.registry_module.model.BugRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BugRepository extends JpaRepository<BugRegistry, String> {

    // Logic: Find all bugs raised by the current user so they can see their history
    // Sorted by updated_at so the most recent failures are at the top
    List<BugRegistry> findByRaisedByOrderByUpdatedAtDesc(String raisedBy);
}