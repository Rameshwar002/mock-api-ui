package com.example.automationbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomationbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomationbackendApplication.class, args);
	}

}
